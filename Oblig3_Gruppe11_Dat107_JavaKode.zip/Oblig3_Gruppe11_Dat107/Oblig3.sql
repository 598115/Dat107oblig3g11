
---------------------------------------------------------------------Ansatt-------------------------------------------------------------------

DROP SCHEMA IF EXISTS oblig3 CASCADE;

CREATE SCHEMA oblig3;
SET search_path TO oblig3;
    

CREATE TABLE Ansatt
(
    ansattnr SERIAL PRIMARY KEY,
    brukernavn varchar(20) UNIQUE,
    fornavn varchar(20) not null,
    etternavn varchar(20) not null,
    ansattdato DATE not null,
    stilling varchar(20) not null,
    manedslonn integer;
     
);

INSERT INTO
  Ansatt(brukernavn, fornavn, etternavn, ansattdato, stilling, manedslonn)
VALUES
    ('tryber', 'Trym', 'Berger', '01-09-2018', 'Elektriker', 24000),
    ('jeb', 'Jan-Erik', 'Berger', '01-09-1992', 'Elektriker', 32000),
    ('mawalker', 'Mathew', 'Walker', '01-12-2019', 'Blikkenslager', 22000),
    ('otouna', 'Una', 'Otomachi', '01-03-2023', 'Sekreter', 24000);
    
 --//////////////////////////////////////////////////ALTERS///////////////////////////////////////////////////////////

ALTER TABLE ANSATT
ADD COLUMN avdelingnr integer

 --Kode for midlertidig manuell insetting av avdelingsnr for ansatte vad laging av database tabeller
UPDATE ANSATT
SET avdelingnr = --Sett inn ulike avdelinger for hver ansatt
WHERE ansattnr = --Sett inn ansattnr
-----------------------------------------------------------------------------------------------------

--Legger til foreign key til avdeling
ALTER TABLE ANSATT
ADD COLUMN avdelingnr integer

ALTER TABLE ANSATT
ADD CONSTRAINT fk_avdelingnr FOREIGN KEY(avdelingnr) REFERENCES AVDELING(avdelingnr);

ALTER TABLE ANSATT
ALTER COLUMN avdelingnr set not null
 
 --///////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
    
-------------------------------------------------------------------Avdeling--------------------------------------------------------

SET search_path TO oblig3;

CREATE TABLE Avdeling
(
    avdelingnr SERIAL PRIMARY KEY,
    avdnavn varchar(20),
    sjef integer NOT NULL,
	CONSTRAINT fk_sjef
	FOREIGN KEY(sjef) 
	REFERENCES ANSATT(ansattnr) 
);

INSERT INTO
  Avdeling(avdnavn, sjef)
VALUES
    ('Elektro', 1),
    ('Rorlegger', 5),
    ('Ventilasjon', 6);

SELECT * FROM AVDELING   


-------------------------------------------------------------------Prosjekt--------------------------------------------------------

SET search_path TO oblig3;

CREATE TABLE Prosjekt
(
    prosjektnr SERIAL PRIMARY KEY,
    prosjektnavn varchar(20),
    prosjektbeskrivelse varchar(30)
);

INSERT INTO
  Prosjekt(prosjektnavn, prosjektbeskrivelse)
VALUES
    ('Lagunen', 'Utbygging av lagunen senter'),
    ('NHH', 'Renovering av NHH'),
    ('Bybanen', 'Bygging av bybanen');

SELECT * FROM Prosjekt   

-------------------------------------------------------------------Prosjekt Deltakelse--------------------------------------------------------

SET search_path TO oblig3;

CREATE TABLE Prosjektdeltakelse
(
    prosjektnr int,
    ansattnr int,
    timer int,
    rolle varchar(20),
    PRIMARY KEY(prosjektnr, ansattnr),
    FOREIGN KEY(prosjektnr) REFERENCES PROSJEKT(prosjektnr),
    FOREIGN KEY(ansattnr) REFERENCES ANSATT(ansattnr)
);

INSERT INTO
  Prosjektdeltakelse(prosjektnr, ansattnr, timer, rolle)
VALUES
    (1, 1, 1500, 'Elektro montoer'),
    (2, 4, 125, 'HMS Ansvarlig'),
    (3, 7, 40, 'Prosjektleder');

SELECT * FROM Prosjektdeltakelse    

















    
  

