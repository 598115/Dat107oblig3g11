package dao;

import entity.Ansatt;
import entity.Prosjekt;
import entity.Prosjektdeltakelse;
import entity.ProsjektdeltakelsePK;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class ProsjektDAO {
	
	private EntityManagerFactory emf;
	
	public ProsjektDAO() {
		 emf = Persistence.createEntityManagerFactory("projectPersistenceUnit");
	}
	
//-----------------------------------------------------------------------//	
	public int LeggTilProsjekt(Prosjekt prosjekt) { //
			
			 EntityManager em = emf.createEntityManager();
			 EntityTransaction tx = em.getTransaction();
			 
			 int result = 0;
		        try {
		        	tx.begin();
		        	em.persist(prosjekt);
		        	tx.commit();	        	
		        }
		        catch(Exception e) {
		        	System.out.println("Feil oppstod\nFeilmelding: " + e);
		        	result = -1;
		        }	        
		        finally {
		            em.close();
		        }
		        return result;
		    }
//-----------------------------------------------------------------------//
	
	public int RegistrerDeltakelse(Ansatt ansatt, Prosjekt prosjekt, String rolle) {
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		int result = 0;
		Prosjektdeltakelse delta = new Prosjektdeltakelse(ansatt, prosjekt, 0, rolle);
		
		 try {
			 tx.begin();
			 em.persist(delta);
			 tx.commit();	        	
	        }
	        catch(Exception e) {
	        	System.out.println("Feil oppstod\nFeilmelding: " + e);
	        	result = -1;
	        }	        
	        finally {
	            em.close();
	        }
	        return result;
	    }
//----------------------------------------------------------------------//
	
	public Prosjekt FinnProsjektMedId(int prosjektnr) {
		
		EntityManager em = emf.createEntityManager();
		
		try {		
			return em.find(Prosjekt.class, prosjektnr);		     	
	        }
	        catch(Exception e) {
	        	System.out.println("Feil oppstod\nFeilmelding: " + e);
	        	return null;
	        }	        
	        finally {
	            em.close();
	        }	
	}
//----------------------------------------------------------------------//

	public int SkrivTimer(Prosjektdeltakelse delta, int timer) {
		
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        int result = 0;
        int nytimer = delta.getTimer() + timer;
		
		try {		
			tx.begin();
			delta = em.merge(delta);
			delta.setTimer(nytimer);
			tx.commit();
	        }
	        catch(Exception e) {
	        	System.out.println("Feil oppstod\nFeilmelding: " + e);
	        	return -1;
	        }	        
	        finally {
	            em.close();
	        }	
		return result;
	}
//--------------------------------------------------------------------//
	
	public Prosjektdeltakelse finnProsjektdeltakelse(int ansattnr, int prosjektnr) {
		
       EntityManager em = emf.createEntityManager();
       ProsjektdeltakelsePK pk = new ProsjektdeltakelsePK(ansattnr, prosjektnr);
		
		try {		
			return em.find(Prosjektdeltakelse.class, pk);		     	
	        }
	        catch(Exception e) {
	        	System.out.println("Feil oppstod\nFeilmelding: " + e);
	        	return null;
	        }	        
	        finally {
	            em.close();
	        }	
	}
//------------------------------------------------------------------//
	

}
