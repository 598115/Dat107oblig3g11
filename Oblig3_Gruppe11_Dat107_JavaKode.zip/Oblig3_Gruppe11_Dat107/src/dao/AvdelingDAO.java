package dao;

import java.util.List;

import entity.Ansatt;
import entity.Avdeling;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

public class AvdelingDAO {

	private EntityManagerFactory emf;
	
	public AvdelingDAO() {
		 emf = Persistence.createEntityManagerFactory("projectPersistenceUnit");
	}
	
//-----------------------------------------------------------------------//	
	public Avdeling finnAvdelingMedavdnr(int avdnr) { //
		
		 EntityManager em = emf.createEntityManager();
	        try {
	        	
	        	return em.find(Avdeling.class, avdnr);
	        	
	        } finally {
	            em.close();
	        }
	    }
//-----------------------------------------------------------------------//
	
	public List<Ansatt> finnAnsatteVedAvdeling(int avdnr) { //
		
		EntityManager em = emf.createEntityManager();
		
		String ql = "SELECT a FROM Ansatt AS a  "
				+ "WHERE a.avdeling.avdelingNr = :avdnr";
		
		try {
			TypedQuery<Ansatt> query = em.createQuery(ql, Ansatt.class);
			query.setParameter("avdnr", avdnr);
			return query.getResultList();			
		}
		catch(Exception e) {
			System.out.println("Feil oppstod\nFeilmelding: " + e.toString());
	    	return null;
		}
		finally {
			em.close();
		}		
	}
//-----------------------------------------------------------------------//	
	
	public Ansatt finnSjefVedAvdeling(int avd) { //
		
		EntityManager em = emf.createEntityManager();
		
		String ql = "SELECT a FROM Ansatt as a "
				+ "WHERE a.avdeling.avdelingNr = :avdnr AND a.avdeling.sjef.ansattNr = a.ansattNr";
		try {
			
			TypedQuery<Ansatt> query = em.createQuery(ql, Ansatt.class);
			query.setParameter("avdnr", avd);
			return query.getSingleResult();
			
		}
		catch(Exception e) {
	    	System.out.println("Feil oppstod, avdeling finnes ikke\nFeilmelding: " + e.toString());
	    	return null;
	    }
		finally {
			em.close();
		}		
	}
//----------------------------------------------------------------------//	
	
	public int oppdaterAvdeling(int nyavd, int ansnr) { //
		
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        int result = 0;
		
		try {		
			tx.begin();
			Ansatt ans = em.find(Ansatt.class, ansnr);
			Avdeling avd = finnAvdeling(nyavd);
			ans = em.merge(ans);
			ans.setAvdeling(avd);	
			tx.commit();					
		}
		catch(Exception e) {
			System.out.println("Feil oppstod. Mulige feil: avdeling finnes ikke, ansatt finnes ikke\n"
					+ "eller sjef kan ikke bytte avdeling\nFeilmelding: " + e.toString());
			result = -1;
		}
		finally {
			em.close();
		}
		return result;		
	}
//---------------------------------------------------------------------//	
	
	private Avdeling finnAvdeling(int avdnr) { //
		
		EntityManager em = emf.createEntityManager();
		try {
		return em.find(Avdeling.class, avdnr);
		}
		finally {
			em.close();
		}
	}
//---------------------------------------------------------------------//
	
	public int leggTilAvdeling(String navn, Ansatt sjef) { //
		
		EntityManager em = emf.createEntityManager();
	    EntityTransaction tx = em.getTransaction();
	    int result = 0;
	    Avdeling avd = new Avdeling(navn);
	    avd.setSjef(sjef);
	
		try {
		tx.begin();
		
		avd = em.merge(avd);
		em.persist(avd);
		em.flush();
		sjef = em.merge(sjef);
		sjef.setAvdeling(avd);

		tx.commit();		
		}
		catch(Exception e) {
			System.out.println("Feil oppstod ved oppretting av ny avdeling\nFeilmelding: " + e.toString());
			result = -1;
		}	
		finally {
			em.close();
		}
		return result;
	}	
//---------------------------------------------------------------------//
	
	public boolean erSjef(int ansattnr) {
		
        EntityManager em = emf.createEntityManager();
        boolean result = true;
        List<Avdeling> liste = null;
		
		String ql = "SELECT a FROM Avdeling as a "
				+ "WHERE a.sjef.ansattNr = :ansattNr";
		try {
			
			TypedQuery<Avdeling> query = em.createQuery(ql, Avdeling.class);
			query.setParameter("ansattNr", ansattnr);
			liste = query.getResultList();
			
		}
		catch(Exception e) {
	    	System.out.println("Feil oppstod: " + e.toString());
	    }
		finally {
			em.close();
			if(liste.isEmpty()) {
				result = false;
			}	
		}		
		return result;
		
	}
		
}
	

