package dao;

import java.time.LocalDate;
import java.util.List;

import entity.Ansatt;
import entity.Avdeling;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NonUniqueResultException;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

public class AnsattDAO {
	
	private EntityManagerFactory emf;

	public AnsattDAO() {
  	    emf = Persistence.createEntityManagerFactory("projectPersistenceUnit");	 
	}
	
//-------------------------------------------------------------------------------//	
	
	public void settInn(int lonn, String bnavn, String fnavn, String enavn, String stilling, LocalDate dato, Avdeling avd) { //
			
	    EntityManager em = emf.createEntityManager();
	    EntityTransaction tx = em.getTransaction();

	    Ansatt ny = new Ansatt(lonn, bnavn, fnavn, enavn, stilling,
			dato, avd);
	    try {	
		tx.begin();
		em.persist(ny);
		tx.commit();	
	   }
	    catch(Exception e) {
	    	System.out.println("Feil oppstod\nFeilmelding: " + e.toString());
	    }
	    finally {
		em.close();
	  }	    
	 }
//-----------------------------------------------------------------------------//	
	public Ansatt finnAnsattMedId(int id) { //
		
		EntityManager em = emf.createEntityManager();
			
		try {		
			return em.find(Ansatt.class, id);			
		}
		finally {
			em.close();
		}
	}
//----------------------------------------------------------------------------//
	
	
	public Ansatt finnAnsattMedBrukernavn(String bnavn) { //
		
		EntityManager em = emf.createEntityManager();
		String ql = "SELECT a FROM Ansatt a WHERE a.brukernavn LIKE :bnavn";
		Ansatt a = null;
		
		try {
			
		TypedQuery<Ansatt> query = em.createQuery(ql, Ansatt.class);
		query.setParameter("bnavn", bnavn);
		a = query.getSingleResult();
		}
		catch(NonUniqueResultException e) {
			System.out.println("Feil oppstod: \n" + e.toString());
		}
		finally {
			em.close();
		}
		return a;
	}	
//------------------------------------------------------------------------------//
	
	public List<Ansatt> finnAlleAnsatte() { //
		
		EntityManager em = emf.createEntityManager();
		String ql = "SELECT a FROM Ansatt a";
		
		try {
			
		TypedQuery<Ansatt> query = em.createQuery(ql, Ansatt.class);  //*TODO* Bedre exception catcher?
		return query.getResultList();
		                                     
		}
		catch(Exception e) {
			System.out.println("Feil oppstod\nFeilmelding: " + e.toString());
			return null;
		}
		finally {
			em.close();
		}
	}
//-------------------------------------------------------------------------------//
		
	public int oppdaterLonn(int id, int nylonn) { //
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		int result = 0;
		
		try {
			tx.begin();
			Ansatt a = em.find(Ansatt.class, id);
			a = em.merge(a);
			a.setManedslonn(nylonn);
			tx.commit();
		}
		catch(IllegalArgumentException e) {
			System.out.println("Den ansatte finnes ikke\n Feilmelding: " + e.toString());
			result = -1;
		}
		finally {
			em.close();
		}
		return result;
	}
//-------------------------------------------------------------------------------//
	
	public int oppdaterStilling(int id, String nystilling) {//
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		int result = 0;
		
		try {
			tx.begin();
			Ansatt a = em.find(Ansatt.class, id);
			a.setStilling(nystilling);
			tx.commit();
		}
		catch(NullPointerException e) {
		System.out.println("Den ansatte finnes ikke\nFeilmelding: " + e.toString());
		result = -1;
		}		
		finally {
			em.close();
		}
		return result;
	}
//-------------------------------------------------------------------------------//	
	
	
}
