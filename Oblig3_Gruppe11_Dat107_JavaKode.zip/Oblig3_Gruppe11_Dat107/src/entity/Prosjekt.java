package entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(schema = "oblig3")
public class Prosjekt {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int prosjektNr;
	private String prosjektNavn;
	private String prosjektBeskrivelse;
	
	@OneToMany(mappedBy="prosjekt", fetch=FetchType.EAGER)
    private List<Prosjektdeltakelse> deltakelser;

	public Prosjekt() {		
	}

	public Prosjekt(String prosjektNavn, String prosjektBeskrivelse) {
		this.prosjektNavn = prosjektNavn;
		this.prosjektBeskrivelse = prosjektBeskrivelse;
	}
	
	public void leggTilProsjektdeltakelse(Prosjektdeltakelse prosjektdeltakelse) {
		deltakelser.add(prosjektdeltakelse);
	}

	public String getProsjektNavn() {
		return prosjektNavn;
	}

	public void setProsjektNavn(String prosjektNavn) {
		this.prosjektNavn = prosjektNavn;
	}

	public String getProsjektBeskrivelse() {
		return prosjektBeskrivelse;
	}

	public void setProsjektBeskrivelse(String prosjektBeskrivelse) {
		this.prosjektBeskrivelse = prosjektBeskrivelse;
	}

	@Override
	public String toString() {
		return "Prosjektnummer: " + prosjektNr + "\nprosjektNavn: " + prosjektNavn + "\nprosjekt beskrivelse: "
				+ prosjektBeskrivelse;
	}
	
	
	public String skrivUtMedDeltakelser() {
		
		return this.toString() + "\n" + deltakelser.toString();
         	
	}

}
