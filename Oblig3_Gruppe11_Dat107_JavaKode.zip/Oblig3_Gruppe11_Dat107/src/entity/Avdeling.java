package entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(schema = "oblig3")
public class Avdeling {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int avdelingNr;
	private String avdNavn;
	
	@OneToOne                                                     ////////////////////Test change @ManyToOne
	@JoinColumn(name = "sjef")
	private Ansatt sjef;


	public Avdeling(String avdelingNavn, Ansatt sjef) {
		this.avdNavn = avdelingNavn;
		this.sjef = sjef;
	}
	public Avdeling(String avdelingNavn) {
		this.avdNavn = avdelingNavn;
	}
	
	public Avdeling() {

	}
	public String getAvdelingNavn() {
		return avdNavn;
	}
	public void setAvdelingNavn(String avdelingNavn) {
		this.avdNavn = avdelingNavn;
	}
	public Ansatt getSjef() {
		return sjef;
	}
	public void setSjef(Ansatt sjef) {
		this.sjef = sjef;
	}
	public int getAvdelingNr() {
		return avdelingNr;
	}
	
	@Override
	public String toString() {
		
		
		return "Avdelings nummer: " + avdelingNr + "\nAvdelings navn/beskrivelse: " + avdNavn
				+ "\nAvdelingens sjef: " + sjef.toString();
		
	}

}
