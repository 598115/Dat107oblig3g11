package entity;

@SuppressWarnings("unused")
public class ProsjektdeltakelsePK {
	
	private int ansatt;
	private int prosjekt;

	public ProsjektdeltakelsePK() {}

	public ProsjektdeltakelsePK(int ansatt, int prosjekt) {
		this.ansatt = ansatt;
		this.prosjekt = prosjekt;
	}


}
