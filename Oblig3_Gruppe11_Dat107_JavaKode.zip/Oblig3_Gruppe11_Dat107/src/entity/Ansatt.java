package entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(schema = "oblig3")
public class Ansatt {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ansattNr;
	private int manedslonn;
	private String brukernavn;
	private String fornavn;
	private String etternavn;
	private String stilling;
	private LocalDate ansattDato;
	
	@ManyToOne
	@JoinColumn(name = "avdelingnr")
	private Avdeling avdeling;
	
    @OneToMany(mappedBy="ansatt", fetch=FetchType.EAGER)
    private List<Prosjektdeltakelse> deltakelser;
	
	public Ansatt() {
		
	}
	public Ansatt(int manedslonn, String brukernavn, String fornavn, String etternavn, String stilling,
			LocalDate ansattDato, Avdeling avdeling) {
		this.manedslonn = manedslonn;
		this.brukernavn = brukernavn;
		this.fornavn = fornavn;
		this.etternavn = etternavn;
		this.stilling = stilling;
		this.ansattDato = ansattDato;
		this.avdeling = avdeling;
	}
	
	public void leggTilProsjektdeltakelse(Prosjektdeltakelse prosjektdeltakelse) {
		deltakelser.add(prosjektdeltakelse);
	}
	
	public int getManedslonn() {
		return manedslonn;
	}
	public void setManedslonn(int manedslonn) {
		this.manedslonn = manedslonn;
	}
	public String getBrukernavn() {
		return brukernavn;
	}
	public void setBrukernavn(String brukernavn) {
		this.brukernavn = brukernavn;
	}
	public String getFornavn() {
		return fornavn;
	}
	public void setFornavn(String fornavn) {
		this.fornavn = fornavn;
	}
	public String getEtternavn() {
		return etternavn;
	}
	public void setEtternavn(String etternavn) {
		this.etternavn = etternavn;
	}
	public String getStilling() {
		return stilling;
	}
	public void setStilling(String stilling) {
		this.stilling = stilling;
	}
	public LocalDate getAnsattDato() {
		return ansattDato;
	}
	public void setAnsattDato(LocalDate ansattDato) {
		this.ansattDato = ansattDato;
	}
	public int getAnsattNr() {
		return ansattNr;
	}
	public Avdeling getAvdeling() {
		return avdeling;
	}
	public void setAvdeling(Avdeling avdeling) {
		this.avdeling = avdeling;
	}
		
	public void setAnsattNr(int ansattNr) {
		this.ansattNr = ansattNr;
	}	
	
	public List<Prosjektdeltakelse> getDeltakelser() {
		return deltakelser;
	}
	@Override
	public String toString() {
			
		return "\n[AnsattNr]: " + ansattNr + " [Stilling]: " + stilling
				+ "\n[Brukernavn]: " + brukernavn + " [Ansatt Dato]: " + ansattDato.toString()
				+ "\n[Fornavn]: " + fornavn + " [Etternavn]: " + etternavn
				+ "\n[Manedslonn]: " + manedslonn + "\n[Avdeling nummer]: " + avdeling.getAvdelingNr()
				+ "\n=================================================";		
	}
	

}
