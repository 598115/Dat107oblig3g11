package entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(schema = "oblig3")
@IdClass(ProsjektdeltakelsePK.class)
public class Prosjektdeltakelse {
	
	@Id
	@ManyToOne
	@JoinColumn(name = "ansattNr")
	private Ansatt ansatt;
	
	@Id
	@ManyToOne
	@JoinColumn(name = "prosjektNr")
	private Prosjekt prosjekt;
	
	private int timer;
    private String rolle;
    
 
	public Prosjektdeltakelse() {}


	public Prosjektdeltakelse(Ansatt ansatt, Prosjekt prosjekt, int timer, String rolle) {
		this.ansatt = ansatt;
		this.prosjekt = prosjekt;
		this.timer = timer;
		this.rolle = rolle;
		prosjekt.leggTilProsjektdeltakelse(this);
		ansatt.leggTilProsjektdeltakelse(this);
	}


	public Ansatt getAnsatt() {
		return ansatt;
	}


	public void setAnsatt(Ansatt ansatt) {
		this.ansatt = ansatt;
	}


	public Prosjekt getProsjekt() {
		return prosjekt;
	}


	public void setProsjekt(Prosjekt prosjekt) {
		this.prosjekt = prosjekt;
	}


	public int getTimer() {
		return timer;
	}


	public void setTimer(int timer) {
		this.timer = timer;
	}


	public String getRolle() {
		return rolle;
	}


	public void setRolle(String rolle) {
		this.rolle = rolle;
	}


	@Override
	public String toString() {
		return "\n//---------------------Prosjektdeltagelse info for ansatt nr " + ansatt.getAnsattNr() + 
				"--------------------//" + "\nInfo om den ansatte: \n" 
	    + ansatt + "\nInfo om prosjektet for ansatte: " + prosjekt + "\ntimer arbeidet: " + timer + "\nrolle: "
				+ rolle + "\n//-----------------------------------------------------------------------//\n";
	}
	
	
	

}
