package klient;

public class MainOblig3 {
	
	public static void main(String[] args) {
	
	MenyDataBase meny = new MenyDataBase();
    meny.start();
			
	}	
	
}
