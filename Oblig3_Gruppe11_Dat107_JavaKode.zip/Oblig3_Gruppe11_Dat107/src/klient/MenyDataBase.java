package klient;

import java.time.LocalDate;
import java.util.Scanner;


public class MenyDataBase {

	private Tekstgrensesnitt tekstgr;
	private Scanner scan;
	
	public MenyDataBase() {
		tekstgr = new Tekstgrensesnitt();
		scan = new Scanner(System.in);
	}
	
	public void start() {
	
	boolean ferdig = false;	
		
	while(!ferdig) {	
		
		startTekst();
		
		System.out.println("Vill du gjore noe mer?\n"
				+ "[1]Ja\n"
				+ "[2]Nei");
		
		String valg = scan.next();
		
		if(valg.equals("2")) {
			ferdig = true;
			scan.close();
			System.out.println("Programmet er avsluttet");
		}
		if(!(valg.equals("1")) && !(valg.equals("2"))) {
		    System.out.println("Ugyldig svar, avslutter menyen");
			ferdig = true;
		}
	}
  }
	
	
	private void startTekst() {
		
		String line = "==============================================================================";
		
		String meny = line + "\nVelkommen til database menyen for prosjekt og ansatte\n"
				+ "Vennligst skriv inn nummeret i konsollen for operasjonen du vill gjore\n"
				+ "NB: Systemet svikter om mellomrom blir brukt ved inputs, bruk _\n"
				+ "Alternativer:\n"
				+ "[1]Vis all informasjon om en ansatt\n"
				+ "[2]Legg til en ny ansatt\n"
				+ "[3]Vis alle ansatte\n"
				+ "[4]Oppdater en ansatt sin informasjon\n"
				+ "[5]Vis informasjon om an avdeling\n"
				+ "[6]Vis alle ansatte ved en avdeling\n"
				+ "[7]Oppdater avdelingen til en ansatt\n"
				+ "[8]Opprett en ny avdeling\n"
				+ "[9]Opprett et nytt prosjekt\n"
				+ "[10]Registrer deltakelse i et prosjekt for en ansatt\n"
				+ "[11]Skriv nye timer for en ansatt\n"
				+ "[12]Skriv ut info om et prosjekt"
				+ "Skriv inn 0 for avslutting av menyen\n" + line + "\nSkriv inn ditt valg og trykk enter: ";
		System.out.println(meny);
					
		boolean gyldigvalg = false;
		String valg = "";
		
		valg = scan.next();
		
		while(!gyldigvalg && !(valg.equals("0"))) {	
			
//----------------------------------------------------------------------------------//			
		if(valg.equals("1")) {
			valg = "";
			
			while(!gyldigvalg) {				
				gyldigvalg = valgFinnAnsatt();
				if(!gyldigvalg) {
		           System.out.println("Ugyldig svar, prov igjen: ");
				}
		    }
//------------------------------------------------------------------------------------//			
		}
		else if(valg.equals("2")) {	
			
		valg = "";
		gyldigvalg = valgLeggTilAnsatt();
			
		 }	
//------------------------------------------------------------------------------------//
		
		else if(valg.equals("3")) {
			tekstgr.skrivAlleAnsatte();
			gyldigvalg = true;
			valg = "";
		}
//------------------------------------------------------------------------------------//
		
		else if(valg.equals("4")) {			
			
			while(!gyldigvalg) {
			
			  gyldigvalg = valgOppdaterAnsatt();	

		    }
		}		
//-----------------------------------------------------------------------------------//	
		else if(valg.equals("5")) {
		
		   gyldigvalg = valgSkrivAvdeling();		
		}
//-----------------------------------------------------------------------------------//		
		
		else if(valg.equals("6")) {
			gyldigvalg = valgSkrivAnsatteVedAvdeling();
		}						
//-----------------------------------------------------------------------------------//
		
		else if(valg.equals("7")) {
			gyldigvalg = valgOppdaterAnsattAvdeling();
		}						
//-----------------------------------------------------------------------------------//	
		
		else if(valg.equals("8")) {
			gyldigvalg = valgNyAvdeling();
		}
//-----------------------------------------------------------------------------------//		
		
		else if(valg.equals("9")) {
			gyldigvalg = valgNyttProsjekt();
		}
//-----------------------------------------------------------------------------------//		
		
		else if(valg.equals("10")) {
			gyldigvalg = valgRegistrerDeltakselse();
		}
//----------------------------------------------------------------------------------//
		
		else if(valg.equals("11")) {
			gyldigvalg = valgSkrivTimer();
		}
		
//-----------------------------------------------------------------------------------//
		
		else if(valg.equals("12")) {
			gyldigvalg = valgSkrivInfoProsjekt();
		}
//-----------------------------------------------------------------------------------//		
		
		if(!gyldigvalg) {
			System.out.println("Ugyldig valg, velg om igjen");
			valg = scan.next();
		}		
	   } //While ikke ferdig med valg		
	}
//-----------------------------Private hjelpe-metoder for valge metodene-------------//
	
	private boolean valgFinnAnsatt() {
				
		String valg;
		System.out.println("Hvordan vill du finne den ansatte?\n"
				+ "[1]Med Ansatt nummer\n"
				+ "[2]Med brukernavn");
		       valg = scan.next();	
		
	           if(valg.equals("1")) {
	        	   valg = "";
	        	   System.out.println("Skriv inn ansatt nummer: ");
	        	   String valg2 = scan.next();
	        	   int intvalg = Integer.parseInt(valg2);
	        	   tekstgr.skrivAnsattfraID(intvalg);
	        	   return true;
	           }
	           if(valg.equals("2")) {
	        	   System.out.println("Skriv inn brukernavn: ");
	        	   String valg2 = scan.next(); 		        	   
	        	   tekstgr.skrivAnsattfraBrukernavn(valg2);
	        	   return true;	       
	           }
	           else {
	        	   return false;
	           }
	}
	
	private boolean valgLeggTilAnsatt() {
		
		String valg;
		
		System.out.println("Skriv inn info om ny ansatt\n"
				+ "Skriv inn brukernavn");
				valg = scan.next();
			    String brukernavn = valg;
			    System.out.println("Skriv inn fornavn");
			    valg = scan.next();
			    String fornavn = valg;
			    System.out.println("Skriv inn etternavn");
			    valg = scan.next();
			    String etternavn = valg;
			    System.out.println("Skriv inn stilling");
			    valg = scan.next();
			    String stilling = valg;
			    System.out.println("Skriv inn manedslonn");
			    valg = scan.next();
			    int lonn = Integer.parseInt(valg);
			    System.out.println("Skriv inn avdelingsnummer");
			    valg = scan.next();
			    int avdnr = Integer.parseInt(valg);
			    
				tekstgr.leggTilnyAnsatt(lonn, brukernavn, fornavn, etternavn, stilling, LocalDate.now(), avdnr);
				return true;
	}
	
	private boolean valgOppdaterAnsatt() {
		
		String valg;
		
		System.out.println("Hva vill du oppdatere? \n"
				+ "[1]Stilling\n"
				+ "[2]Manedslonn\n");
		        valg = scan.next();	
		
	           if(valg.equals("1")) {
	        	   
	        	   System.out.println("Skriv inn ansattnr til person du vill bytte stilling til");
	        	   valg = scan.next();
	        	   int intvalg = Integer.parseInt(valg);
	        	   
	        	   valg = "";
	        	   System.out.println("Skriv inn ny stilling: ");
	        	   valg = scan.next();
	        	   tekstgr.oppdaterStilling(intvalg, valg);
	        	   return true;
	           }
	           if(valg.equals("2")) {
	        	   
	        	   System.out.println("Skriv inn ansattnr til person du vill bytte lonn til");
	        	   valg = scan.next();
	        	   int intvalg = Integer.parseInt(valg);
	        	   
	        	   valg = "";
	        	   System.out.println("Skriv inn ny manedslonn: ");
	        	   valg = scan.next();
	        	   int lonn = Integer.parseInt(valg);
	        	   tekstgr.oppdaterLonn(intvalg, lonn);
	        	   return true;        	 
	           }
	           return false;
	}
	
	private boolean valgSkrivAvdeling() {
		
		String valg = "";
		System.out.println("Skriv inn avdelingsnummer til oensket avdeling: ");
		valg = scan.next();
		int valgNr = Integer.parseInt(valg);
		tekstgr.skrivAvdelingfraAvdNr(valgNr);
		return true;	
		
	}
	
	private boolean valgSkrivAnsatteVedAvdeling() {
		
		String valg = "";
		System.out.println("Skriv inn avdelingsnummer til oensket avdeling: ");
		valg = scan.next();
		int valgNr = Integer.parseInt(valg);
		tekstgr.skrivAnsatteVedAvdeling(valgNr);
		return true;
	}
	
	private boolean valgOppdaterAnsattAvdeling() {
		
		String valg = "";
		System.out.println("Skriv inn ansattnummeret til personen du vill oppdatere: ");
		valg = scan.next();
		int valgNr = Integer.parseInt(valg);
		System.out.println("Skriv inn det nye avdelingsnummetet: ");
		valg = scan.next();
		int valgNr2 = Integer.parseInt(valg);
		tekstgr.oppdaterAnsattAvdeling(valgNr2, valgNr);
		return true;				
	}
	
    private boolean valgNyAvdeling() {
		
		String valg = "";
		String valg2 = "";
		System.out.println("Skriv inn navn/beskrivelse til ny avdeling: ");
		valg = scan.next();
		System.out.println("Skriv inn ansattnr til sjefen for den nye avdelingen: ");
		valg2 = scan.next();
		int valgansattnr = Integer.parseInt(valg2);
		tekstgr.leggTilNyAvdeling(valg, valgansattnr);
		return true;		
		
	}
    
    private boolean valgNyttProsjekt() {
    	
    	String valg = "";
		String valg2 = "";
		System.out.println("Skriv inn navn til nytt prosjekt: ");
		valg = scan.next();
		System.out.println("Skriv inn beskrivelse til ny avdeling: ");
		valg2 = scan.next();   	
    	tekstgr.LeggTilProsjekt(valg, valg2);
    	return true;
    }
    
    private boolean valgRegistrerDeltakselse() {
    	
    	String valg = "";
		int intvalg = 0;
		int intvalg2 = 0;
		
		System.out.println("Skriv inn ansatt nummer til den du vill registrere: ");
		valg = scan.next();
		intvalg = Integer.parseInt(valg);
		System.out.println("Skriv inn prosjektnummer til prosjektet: ");
		valg = scan.next();   	
		intvalg2 = Integer.parseInt(valg);
		System.out.println("Skriv inn rollen til ansatte i prosjektet: ");
    	valg = scan.next();
    	tekstgr.RegistrerDeltakselse(valg, intvalg, intvalg2);
    	return true;
    }
    
    private boolean valgSkrivTimer() {
    	
    	String valg = "";
		int intvalg = 0;
		int intvalg2 = 0;
		int intvalg3 = 0;
		
		System.out.println("Skriv inn ansatt nummer til den du vill skrive timer for: ");
		valg = scan.next();
		intvalg = Integer.parseInt(valg);
		System.out.println("Skriv inn prosjektetnummer til prosjektet du vill skrive til: ");
		valg = scan.next();   	
		intvalg2 = Integer.parseInt(valg);
		System.out.println("Skriv inn antall timer. Timer skrevet inn vill bli lagt til eksisterende timer: ");
    	valg = scan.next();
    	intvalg3 = Integer.parseInt(valg);
    	tekstgr.SkrivTimer(intvalg, intvalg2, intvalg3);
    	return true;
    	
    }
    
    private boolean valgSkrivInfoProsjekt() {
    	
    	String valg = "";
		int intvalg = 0;
    	
		System.out.println("Skriv inn prosjektnummer til prosjektet: ");
		valg = scan.next();
		intvalg = Integer.parseInt(valg);
		
    	tekstgr.SkrivProsjektdeltakelseData(intvalg);
    	return true;
    	
    }

}
