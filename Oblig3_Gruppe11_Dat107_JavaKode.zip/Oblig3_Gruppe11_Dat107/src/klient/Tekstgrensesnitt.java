package klient;

import java.time.LocalDate;
import java.util.List;

import dao.AnsattDAO;
import dao.AvdelingDAO;
import dao.ProsjektDAO;
import entity.Ansatt;
import entity.Avdeling;
import entity.Prosjekt;
import entity.Prosjektdeltakelse;

public class Tekstgrensesnitt {

	private AnsattDAO andao;
	private AvdelingDAO avdao;
	private ProsjektDAO prodao;
	
	public Tekstgrensesnitt() {
		andao = new AnsattDAO();
		avdao = new AvdelingDAO();
		prodao = new ProsjektDAO();
	}
	
	public void skrivAnsattfraID(int id) {
	
			andao = new AnsattDAO();		
			Ansatt a = andao.finnAnsattMedId(id);
			if(a != null) {
			System.out.println("Ansatt funnet med AnsattNr: \n" + a.toString());
			}
			else{
				System.out.println("Ansatt med det ansattnummeret finnes ikke");
			}
	}
	
	public void leggTilnyAnsatt(int lonn, String bnavn, String fnavn, String enavn, String stilling, LocalDate dato, int avdnr) {
		
		avdao = new AvdelingDAO();
		Avdeling avd = avdao.finnAvdelingMedavdnr(avdnr); 
		andao.settInn(lonn, bnavn, fnavn, enavn, stilling, dato, avd);
		System.out.println("Ny ansatt ble insatt");
	
	}
	
	public void skrivAnsattfraBrukernavn(String bnavn) {
		
		andao = new AnsattDAO();
		Ansatt finn = andao.finnAnsattMedBrukernavn(bnavn);
		if(finn != null) {
			System.out.println("Ansatt funnet med brukernavn: \n" + finn.toString());
			}
			else{
				System.out.println("Ansatt med det brukernavnet finnes ikke");
			}	
	}
	
	
	public void skrivAlleAnsatte() {
		
		andao = new AnsattDAO();
		List<Ansatt> ansatte = andao.finnAlleAnsatte();
		if(ansatte != null) {
		System.out.println("Liste over alle ansatte: \n" + ansatte.toString());
		}
	}
	
	
	public void oppdaterLonn(int id, int lonn) {
		
		andao = new AnsattDAO();
		int result = andao.oppdaterLonn(id, lonn);
		if (result != -1) {
		System.out.println("Lonnen til ansatt med ansattNr: " + id + "  Ble oppdatert til: " + lonn);
		}
	}
	
	public void oppdaterStilling(int id, String nystilling) {
	
	andao = new AnsattDAO();	
	int result = andao.oppdaterStilling(id, nystilling);
	if(result != -1) {
	System.out.println("Stillingen til ansatt med ansattNr: " + id + "  Ble oppdaterd til: " + nystilling);
	}
   }
	
	public void skrivAvdelingfraAvdNr(int avdnr) { 
		
		andao = new AnsattDAO();
		Avdeling a = avdao.finnAvdelingMedavdnr(avdnr);
		if(a != null) {
			System.out.println(a);
		}		
	}
	
	public void skrivAnsatteVedAvdeling(int avdnr) {
		
		avdao = new AvdelingDAO();	
		Ansatt sjef = avdao.finnSjefVedAvdeling(avdnr);
		
		if(sjef != null) {
		System.out.println("Sjefen ved avdelingen: \n" + sjef.toString());
		
		List<Ansatt> liste = avdao.finnAnsatteVedAvdeling(avdnr);
	      if(liste != null) {
		    System.out.println("Alle ansatte ved avdelingen: \n" + liste.toString());
	      }
		}
		
	}
	
	public void oppdaterAnsattAvdeling(int nyavd, int ansnr) {
		
		avdao = new AvdelingDAO();
		
		if(!avdao.erSjef(ansnr)) {
		
		int result = avdao.oppdaterAvdeling(nyavd, ansnr);
		if(result != -1) {
		System.out.println("Avdelingen ble oppdatert til avdeling nummer: " + nyavd);
		}
	  }
		else {
			System.out.println("Den ansatte er sjef ved en avdeling, kan ikke bytte avdeling");
		}
	}
	
	public void leggTilNyAvdeling(String avdNavn, int sjefid) {
		
	    avdao = new AvdelingDAO();
	    andao = new AnsattDAO();
	    Ansatt sjef = andao.finnAnsattMedId(sjefid);
		int result = avdao.leggTilAvdeling(avdNavn, sjef);
		Ansatt sjefny = andao.finnAnsattMedId(sjefid);
		if(result != -1 && sjef != null) {
			System.out.println("Ny avdeling ble lagt til med navn: " + avdNavn + " og sjef: \n" + sjefny.toString());
		}		
	}
	
	public void LeggTilProsjekt(String prosjektNavn, String prosjektBeskrivelse) {
		
		prodao = new ProsjektDAO();
		Prosjekt ny = new Prosjekt(prosjektNavn, prosjektBeskrivelse);
		int result = prodao.LeggTilProsjekt(ny);
		if(result != -1) {
			System.out.println("Nytt prosjekt ble lagt til: " + ny.toString());
		}
		
	}
	
	public void RegistrerDeltakselse(String rolle, int ansattnr, int prosjektnr) {
		
		avdao = new AvdelingDAO();
		prodao = new ProsjektDAO();
		Ansatt ansatt = andao.finnAnsattMedId(ansattnr);
		Prosjekt prosjekt = prodao.FinnProsjektMedId(prosjektnr);
		
		if(ansatt != null && prosjekt != null) {			
			int result = prodao.RegistrerDeltakelse(ansatt,prosjekt, rolle);
			if(result != -1) {
				System.out.println("Deltakelse i prosjekt: " + prosjekt.toString() + 
						"\nBle registrert for ansatt: " + ansatt.toString());
			}
		}
		else {
			System.out.println("ansatt eller prosjekt finnes ikke");
		}
	}
	
	public void SkrivTimer(int ansattnr, int prosjektnr, int timer) {
		
		Prosjektdeltakelse delta = prodao.finnProsjektdeltakelse(ansattnr, prosjektnr);
		
		if(delta != null) {
		
		int temp = delta.getTimer();
		int nytimer = temp + timer;
		prodao.SkrivTimer(delta, timer);
		System.out.println("Timer ble oppdatert fra: " + temp + "\nTil: " + nytimer);
		
		}
		else {
			System.out.println("Feil oppstod, ansatt deltar ikke ved dette prosjektet");
		}
		
	}
	
	
	public void SkrivProsjektdeltakelseData(int prosjektnr) {
			
		Prosjekt p = prodao.FinnProsjektMedId(prosjektnr);
		
		if(p != null) {
		
		System.out.println(p.skrivUtMedDeltakelser());
		}
		else {
			System.out.println("Prosjektet finnes ikke");
		}
			
	}
	
}
